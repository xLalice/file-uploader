function updatePaperTypeImage() {
    var paperType = document.querySelector('input[name="paperType"]:checked').value;
    var imageUrl = '';

    switch (paperType) {
        case "Silk":
            imageUrl = "./images/silk.jpg";
            break;
        case 'Gloss':
            imageUrl = './images/gloss.jpg';
            break;
        case 'Uncoated':
            imageUrl = './images/uncoated.jpg';
            break;
        case 'Recycled':
            imageUrl = "./images/recycled.jpg";
            break;
        default:
            imageUrl = ''; 
    }

    document.getElementById('paperTypeImage').src = imageUrl;
  }

let paperTypeRadios = document.querySelectorAll('input[name="paperType"]');
paperTypeRadios.forEach(function(radio) {
    radio.addEventListener('change', updatePaperTypeImage);
}); 

function paperWeights() {
    let weights = [90, 115, 130, 150, 170, 200, 240, 250, 300, 350, 400];
    let weightDiv = document.getElementById('paper-weight');

    for (let i = 0; i < weights.length; i++) {
        let weight = weights[i];
        let div = document.createElement('div');
        div.classList.add('custom-radio-btn');
        div.classList.add("m-width-66");
        let content = `
                <input type="radio" id="paper${weight}" name="paperWeight" value="${weight}">
                <label for="paper${weight}">${weight + "gsm"}</label>
        `
        div.innerHTML = content
        weightDiv.appendChild(div);
    }
}

function paperLamination() {
    let options = ["None",  "Gloss Lamination", "Matte Lamination", "Matte Anti-scuff", "Soft Touch Lamination", "UV Matte", "UV Gloss"];
    let laminationDiv = document.getElementById('paper-lamination');

    for (let i = 0; i < options.length; i++) {
        let option = options[i];
        let div = document.createElement('div');
        div.classList.add('custom-radio-btn');
        let content = `
                <input type="radio" id="lamination${i}" name="paperLaminaton" value="${option}">
                <label for="lamination${i}">${option}</label>
        `
        div.innerHTML = content;
        laminationDiv.appendChild(div);
    }
}

updatePaperTypeImage();
paperWeights();
paperLamination();