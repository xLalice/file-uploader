<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $quantity = $_POST['quantity'];
      $orientation = $_POST['orientation'];
      $size = $_POST['size'];
      $colorsFront = $_POST['colorsFront'];
      $colorsBack = $_POST['colorsBack'];
      $paperType = $_POST['paperType'];
      $paperWeight = $_POST['paperWeight'];

      echo "You have ordered the following:<br>";
      echo "Quantity: $quantity<br>";
      echo "Orientation: $orientation<br>";
      echo "Size: $size<br>";
      echo "Colors (Front): $colorsFront<br>";
      echo "Colors (Back): $colorsBack<br>";
      echo "Paper Type: $paperType<br>";
      echo "Paper Weight: $paperWeight<br>";
  }
?>