<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Art Order Form</title>

<link rel="stylesheet" href="style.css">

<link href='https://fonts.googleapis.com/css?family=Rye' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Zenaida' rel='stylesheet'>
</head>
<body>
  <nav>
    <h1 class="home">Euldriq</h1>
    <div class="navbar">
        <ul>
            <li class="home activeTab">Home</li>
            <li id="works">Works</li>
            <div class="dropdown">
                <button class="dropbtn">More</button>
                <div class="dropdown-content">
                  <a id="sketches">Sketches</a>
                  <a id="models">3D Models</a>
                </div>
            </div>
            <li id="about">About</li>
            <li><a href="bandioque-tovi-bmma502.infinityfreeapp.com" target="_blank">Blog</a></li>
            <li id="contact">Contacts</li>
        </ul>
    </div>
  </nav>

<!-- Button to Open the Form Popup -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#orderFormModal">
  Order Art
</button>

<!-- The Modal -->
<div class="modal fade" id="orderFormModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel">Art Order Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="submit_order.php" method="post" id="orderForm">
          <div class="row mb-3">
            <div class="col">
              <label for="quantity" class="form-label">Quantity</label>
              <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
            </div>
            <div class="col"></div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label class="form-label">Orientation</label><br>
              <div class="flexbox">
                <div class="custom-radio-btn">
                  <input type="radio" id="portrait" name="orientation" value="Portrait" checked>
                  <label for="portrait">Portrait</label>
                </div>
                <div class="custom-radio-btn">
                  <input type="radio" id="landscape" name="orientation" value="Landscape">
                  <label for="landscape">Landscape</label>
                </div>
              </div>
            </div>
            <div class="col">
              <label for="size" class="form-label">Size</label>
              <input type="text" class="form-control" id="size" name="size" placeholder="e.g., 24x36 inches" required>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label for="colorsFront" class="form-label">Colors (Front)</label><br>
              <div class="flexbox">
                <div class="custom-radio-btn">
                  <input type="radio" id="color" name="colorsFront" value="Color">
                  <label for="color">Color</label>
                </div>
                <div class="custom-radio-btn">
                  <input type="radio" id="greyscale" name="colorsFront" value="Greyscale" checked>
                  <label for="greyscale">Greyscale</label>
                </div>
              </div>
            </div>
            <div class="col">
            <label for="colorsBack" class="form-label">Colors (Back)</label><br>
              <div class="flexbox">
                <div class="custom-radio-btn">
                  <input type="radio" id="colorsBackNone" name="colorsBack" value="None" checked>
                  <label for="colorsBackNone">None</label>
                </div>
                <div class="custom-radio-btn">
                  <input type="radio" id="colorsBackColor" name="colorsBack" value="Color">
                  <label for="colorsBackColor">Color</label>
                </div>
                <div class="custom-radio-btn">
                  <input type="radio" id="colorsBackGreyscale" name="colorsBack" value="Greyscale">
                  <label for="colorsBackGreyscale">Greyscale</label>
                </div>
              </div>
            </div>
          </div>
          <hr>
          <div class="row mb-3">
            <div class="col">
              <label for="paperType" class="form-label">Paper Type</label>
              <div class="custom-radio-btn fill-width">
                <input type="radio" id="paperSilk" name="paperType" value="Silk">
                <label for="paperSilk">Silk</label>
              </div>
              <div class="custom-radio-btn fill-width">
                <input type="radio" id="paperGloss" name="paperType" value="Gloss" checked>
                <label for="paperGloss">Gloss</label>
              </div>
              <div class="custom-radio-btn fill-width">
                <input type="radio" id="paperUncoated" name="paperType" value="Uncoated">
                <label for="paperUncoated">Uncoated</label>
              </div>
              <div class="custom-radio-btn fill-width">
                <input type="radio" id="paperRecycled" name="paperType" value="Recycled">
                <label for="paperRecycled">Recycled Uncoated</label>
              </div>

            </div>
            <div class="col">
                <label class="form-label">Paper Type Image</label><br>
                <img src="" alt="Paper Type Image" id="paperTypeImage">
            </div>
          </div>
          <div class="row mb-3">
            <label for="paperWeight" class="form-label">Paper Weight:</label>
            <div id="paper-weight" class="col flexbox">

            </div>
          </div>
          <div class="row mb-3">
            <label for="paper-lamination" class="form-label">Lamination(Front)</label>
            <div id="paper-lamination" class="col flexbox">
            </div>
          </div>
          <div class="row mb-3">
            <label for="laminationBack" class="form-label">Lamination(Back)</label>
            <div class="flexbox">
              <div class="custom-radio-btn">
                <input type="radio" id="laminationNone" name="laminationBack" value="None">
                <label for="laminationNone">None</label>
              </div>
              <div class="custom-radio-btn">
                <input type="radio" id="laminationSame" name="laminationBack" value="Same as Front">
                <label for="laminationSame">Same as Front</label>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-12">
              <h3 class="mb-3">Customer Information</h3>
              <hr>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label for="firstName" class="form-label">First Name</label>
              <input type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name" required>
              
            </div>
            <div class="col">
              <label for="lastName" class="form-label">Last Name</label>
              <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name" required>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label for="emailAddress" class="form-label">Email Address</label>
              <input type="email" class="form-control" id="emailAddress" name="emailAddress" required>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label for="address" class="form-label">Address</label>
              <input type="text" class="form-control" id="address" name="address" required>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label for="contactName" class="form-label">Contact Name</label>
              <input type="text" class="form-control" id="contactName" name="contactName" required>
            </div>
            <div class="col">
              <label for="phone" class="form-label">Phone #</label>
              <input type="tel" class="form-control" id="phone" name="phone">
            </div>
          </div>
          <div class="row mb-3">
            <div class="col">
              <label for="mobile" class="form-label">Mobile #</label>
              <input type="tel" class="form-control" id="mobile" name="mobile">
            </div>
          </div>
          <hr>
          <h3>Choose Price & Delivery</h3>
          <div class="row mb-3">
          <div class="row mb-3 delivery-option">
  <div class="col-12">
    <label class="form-label">Select Price and Delivery Option</label>
  </div>
  
  <div class="col-12">
    <div class="form-check delivery-choice">
      <input class="form-check-input" type="radio" name="deliveryOption" id="option1" value="option1" checked>
      <label class="form-check-label" for="option1">
      <span class="badge bg-light-yellow">Best Value</span>
        <div class="row delivery-details">
          <div class="col-md-6 delivery-col">
            <strong>Estimated Delivery:</strong><br> <span class="large">After 7 days</span>
          </div>
          <div class="col-md-6 delivery-col">
            <strong>High Quality</strong><br><span class="large">P 9000</span>
          </div>
          <div class="col-12 delivery-col">
            <ul class="list-unstyled mt-2">
              <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
  <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z"/>
</svg> Printed on a Heidelberg SM XL75</li>
              <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
  <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z"/>
</svg> High quality Litho printing</li>
            </ul>
          </div>
        </div>
      </label>
    </div>

    <div class="form-check delivery-choice">
      <input class="form-check-input" type="radio" name="deliveryOption" id="option2" value="option2">
      <label class="form-check-label" for="option2">
      <span class="badge bg-light-blue">Priority</span>
        <div class="row delivery-details">
          <div class="col-md-6 delivery-col">
            <strong>Estimated Delivery:</strong><br> <span class="large">After 2 days</span>
          </div>
          <div class="col-md-6 delivery-col">
            <strong>High Quality</strong><br> <span class="large">P 900</span>
          </div>
          <div class="col-12 delivery-col">
            <ul class="list-unstyled mt-2">
              <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
  <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z"/>
</svg> Premium fast service</li>
              <li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
  <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z"/>
</svg> Ideal for urgent projects</li>
            </ul>
          </div>
        </div>
      </label>
    </div>
  </div>
</div>


            
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary full-width-btn">Submit Order</button>

          </div>
        </form>
      </div>
    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js"></script>
</body>
</html>
